$(document).ready(function () {
    const API_BASE_URL = document.querySelector('meta[name="api-base-url"]').getAttribute('content');
    const AUTH_TOKEN = localStorage.getItem('auth_token');

    // View Doctor Details
    $('.view-btn').on('click', function () {
        const purchase = $(this).data('purchase');
        console.log('Parsed .data("purchase"):', purchase);

        $('#modal-supplier_id').text(purchase.supplier_id || '');
        $('#modal-supplier-name').text(purchase.supplier.name || '');
        $('#modal-invoice_no').text(purchase.invoice_no || '');
        $('#modal-purchase_date').text(purchase.purchase_date || '');
        $('#modal-total_amount').text(purchase.total_amount || '');
       
        if (purchase.batches?.length > 0) {
            let html = '<table class="table text-center"><thead><tr><th>Product Id</th><th>Product Name</th><th>Batch No</th><th>Expiry Date</th><th>Quantity</th> <th>MRP</th> <th>Purchase Price</th><th>GST</th></tr></thead><tbody>';
            purchase.batches.forEach(slot => {
                html += `<tr>
                    <td>${slot.product_id}</td>
                    <td>${slot.product.name}</td>                    
                    <td>${slot.batch_no}</td>
                    <td>${slot.expiry_date}</td>
                     <td>${slot.quantity}</td>
                     <td>${slot.mrp}</td>
                    <td>${slot.purchase_price}</td>
                     <td>${slot.gst_percent}</td>
                </tr>`;
            });
            html += '</tbody></table>';
            $('#modal-availability-grid').html(html);
        } else {
            $('#modal-availability-grid').html('<p>No availability data.</p>');
        }

        $('#purchaseModal').modal('show');
    });

    // Reset form on modal close
    $('#addpurchaseModal').on('hidden.bs.modal', function () {
        $('#addpurchaseForm')[0].reset();
        $('#id').val('');      
        $('#addpurchaseModalLabel').text('Add Purchase');
        $('#addpurchaseForm button[type="submit"]').text('Add Purchase');
        $('#availability-wrapper').empty();
        batchCount = 0;
        addBatchSlot(); // default slot
    });

    $(document).on('click', '.edit-btn', function () {
        const purchase = $(this).data('purchase'); 
        if (!purchase) {
            console.error("No purchase data found");
            return;
        }

        $('#id').val(purchase.id);
        $('#supplier_id').val(purchase.supplier_id);
        $('#invoice_no').val(purchase.invoice_no);
        $('#purchase_date').val(purchase.purchase_date);
        $('#total_amount').val(purchase.total_amount);

        // Reset batch slots
        $('#batchContainer').empty();
        batchCount = 0;

        if (Array.isArray(purchase.batches) && purchase.batches.length > 0) {
            purchase.batches.forEach(batch => addBatchSlot(batch));
        } else {
            addBatchSlot();
        }

        $('#addpurchaseModalLabel').text('Edit Purchase');
        $('#addpurchaseForm button[type="submit"]').text('Update Purchase');

        const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('addpurchaseModal'));
        modal.show();
        $('#addpurchaseModal').on('hidden.bs.modal', function () {
            $('#addpurchaseForm')[0].reset();
            $('#id').val('');
            $('#batchContainer').empty();
            $('#addpurchaseModalLabel').text('Add Purchase');
            $('#addpurchaseForm button[type="submit"]').text('Add Purchase');
            batchCount = 0;
            addBatchSlot();
        });
    });

    $('#addpurchaseForm').on('submit', function (e) {

    e.preventDefault();
 
    const isEdit = !!$('#id').val();
    const url = isEdit
        ? `${API_BASE_URL}/api/v1/inventory/admin/purchase/${$('#id').val()}`
        : `${API_BASE_URL}/api/v1/inventory/admin/purchase`;

    const method = isEdit ? 'PUT' : 'POST';

    const formData = {
        supplier_id: $('#supplier_id').val(),
        invoice_no: $('#invoice_no').val(),
        purchase_date: $('#purchase_date').val(),
        total_amount: $('#total_amount').val(),
        batches: []
    };


    $('#batchContainer .row').each(function () {
        const row = $(this);
        formData.batches.push({
            product_id: row.find('[name*="[product_id]"]').val(),
            batch_no: row.find('[name*="[batch_no]"]').val(),
            expiry_date: row.find('[name*="[expiry_date]"]').val(),
            quantity: row.find('[name*="[quantity]"]').val(),
            mrp: row.find('[name*="[mrp]"]').val(),
            purchase_price: row.find('[name*="[purchase_price]"]').val(),
            gst_percent: row.find('[name*="[gst_percent]"]').val()
        });
    });

    console.log("formdata",formData);

    $.ajax({
        url: url,
        method: method,
        headers: {
            'Authorization': `Bearer ${AUTH_TOKEN}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        data: JSON.stringify(formData),
        success: function (res) {
            $('#addpurchaseModal').modal('hide');
            $('#addpurchaseForm')[0].reset();
            $('#batchContainer').html('');
            $('#alertBox').html(`<div class="alert alert-success">Purchase ${isEdit ? 'updated' : 'added'} successfully.</div>`);
            setTimeout(() => location.reload(), 1000);
        },
        error: function (xhr) {
            console.error("Error:", xhr.responseText);
            const message = xhr.responseJSON?.message || 'Something went wrong.';
            $('#alertBox').html(`<div class="alert alert-danger">${message}</div>`);
        }
    });
     });
 });

 $(document).ready(function () {
    const API_BASE_URL = document.querySelector('meta[name="api-base-url"]').getAttribute('content');
    const AUTH_TOKEN = localStorage.getItem('auth_token');

    // Handle typing in the search input
    $('#search').on('input', function () {
        const searchTerm = $(this).val();

        //alert(searchTerm);

        if (searchTerm.length < 2) {
            // Clear select if search term is too short
            $('#supplier_id').empty().append('<option value="">-- Select Supplier --</option>');
            return;
        }

        // Fetch matching suppliers from API
        $.ajax({
            url: API_BASE_URL + '/api/v1/admin/supplier',
            method: 'GET',
            dataType: 'json',
            headers: {
                'Authorization': 'Bearer ' + AUTH_TOKEN
            },
            data: {
                search: searchTerm
            },



            success: function (response) {
                const suppliers = response.data || [];


                $('#supplier_id').empty().append('<option value="">-- Select Supplier --</option>');

                // Populate select with new options
                suppliers.forEach(function (supplier) {
                  $('#supplier_id').append(
                  $('<option>', {
                      value: supplier.id,   // <-- this is the important part
                      text: supplier.name
                  })
              );
                });
            },
            error: function (xhr) {
                console.error('Error fetching suppliers:', xhr);
            }
        });
    });
});