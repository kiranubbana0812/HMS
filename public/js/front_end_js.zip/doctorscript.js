$(document).ready(function () {
    $('.view-btn').on('click', function () {

        const doctor = $(this).data('doctor');

        $('#modal-image').attr('src', doctor.user?.image || '');
        $('#modal-name').text(doctor.user?.name || '');
        $('#modal-doctor-id').text(doctor.doctor_id || '');
        $('#modal-department').text(doctor.department?.name || '');
        $('#modal-specialization').text(doctor.specialization || '');
        $('#modal-experience').text(doctor.experience || '');
        $('#modal-consultaion-fee').text(doctor.consultation_fee || '');
        
        $('#doctorModal').modal('show');
    });

    let slotIndex = 1;

    function addAvailabilitySlot(data = {}) {
        const wrapper = document.getElementById('availability-wrapper');
        const newSlot = document.createElement('div');
        newSlot.className = 'row availability-slot mb-3';

        newSlot.innerHTML = `
            <div class="col-md-6">
                <label class="form-label">Day of Week</label>
                <select class="form-select" name="availability[${slotIndex}][days_of_week]" required>
                    <option value="">Select Day</option>
                    ${['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => `
                        <option value="${day}" ${data.days_of_week === day ? 'selected' : ''}>${day}</option>
                    `).join('')}
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Start Time</label>
                <input type="time" class="form-control" name="availability[${slotIndex}][start_time]" value="${data.start_time || ''}" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">End Time</label>
                <div class="d-flex">
                    <input type="time" class="form-control me-2" name="availability[${slotIndex}][end_time]" value="${data.end_time || ''}" required>
                    <button type="button" class="btn btn-danger" onclick="removeSlot(this)">×</button>
                </div>
            </div>
        `;

        wrapper.appendChild(newSlot);
        slotIndex++;
    }

    function removeSlot(button) {
        const row = button.closest('.availability-slot');
        const slotId = row.querySelector('[name$="[id]"]').value;

        if (slotId) {
            deletedSlotIds.push(slotId); // Track it
        }

        row.remove();
    }

});