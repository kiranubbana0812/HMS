<!-- Sidebar Template -->
<div class="col-md-2 sidebar" id="sidebar">
    <nav class="nav flex-column">
        <a class="nav-link active" href="/doctorsinfo">
            <i class="fas fa-tachometer-alt me-2"></i>
            <span>Dashboard</span>
        </a>
        <a class="nav-link" href="/appointments">
            <i class="fas fa-calendar-check me-2"></i>
            <span>Appointments</span>
        </a>
        <a class="nav-link" href="/">
            <i class="fas fa-chart-bar me-2"></i>
            <span>Reports</span>
        </a>
        <a class="nav-link" href="/">
            <i class="fas fa-ticket-alt me-2"></i>
            <span>Tickets</span>
        </a>
    </nav>
</div>
