@extends('layouts.app')
@push('styles')
    <link href="{{ asset('css/insidestyles.css') }}" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <style>
    .ui-autocomplete {
		z-index: 9999 !important; /* Ensures list is above modal backdrop */
	}

.btn-success {
  background-color: #7c4dff !important;
  border-color: #7c4dff !important;
}

.btn-success:hover {
  background-color: #693de6 !important; /* Slightly darker on hover */
  border-color: #693de6 !important;
}modal-info {
  max-width: 50px;
  margin: 0 auto;
  font-family: Arial, sans-serif;
}

.modal-info-row {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  border-bottom: 1px solid #eee;
}

.modal-label {
  flex: 1;
  font-weight: bold;
  text-align: left;
}

.modal-value {
  flex: 1;
  text-align: left;
}

    </style>
@endpush

@section('content')
<div class="container-fluid p-0">
    <div class="row g-0">
        <div class="col-md-2">
            @include('superAdminSidebar')
        </div>
         <div class="col-md-10 main-content" id="mainContent">
                <!-- Appointments Cards -->
              <div class="content-header d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0"><i class="fas fa-user-injured me-2"></i>Purchase</h4>
                    <div class="action-buttons">
                         <button class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#addpurchaseModal">
                        <i class="fas fa-plus me-1"></i>
                        Add purchase
                    </button>
                    </div>
                </div>
            
                <div id="alertBox"></div>
            <div class="dashboard-card">
    <div class="table-responsive">
        <table class="table table-hover text-center w-100 m-0">
            <thead>
                <tr>
                    <th>Supplier Id</th>
                    <th>Supplier Name</th>
                    <th>Invoice No</th>
                    <th>Purchase Date</th>
                    <th>Total Amount</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($purchasesData as $purchaseData)
                    <tr>
                        <td>{{ $purchaseData['supplier_id'] ?? '-' }}</td>
                        <td>{{ $purchaseData['supplier']['name'] ?? '-' }}</td>
                        <td>{{ $purchaseData['invoice_no'] ?? '-' }}</td>
                        <td>{{ $purchaseData['purchase_date'] ?? '-' }}</td>
                        <td>{{ $purchaseData['total_amount'] ?? '-' }}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary me-1 view-btn" data-purchase='@json($purchaseData)' data-bs-toggle="modal" data-bs-target="#purchaseModal">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-warning me-1 edit-btn" data-purchase='@json($purchaseData)'>
                                <i class="fas fa-edit"></i>
                            </button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <x-pagination :pagination="$pagination" :filters="$filters" />
    </div>
</div>

    <div id="alertBox"></div>
    <div class="modal fade" id="purchaseModal" tabindex="-1" role="dialog" aria-labelledby="purchaseModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="purchaseModalLabel">Purchase Details</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
        <div class="modal-body">
          <div class="modal-info">
            <div class="modal-info-row">
              <span class="modal-label">Supplier Id:</span>
              <span id="modal-supplier_id" class="modal-value"></span>
            </div>
            <div class="modal-info-row">
              <span class="modal-label">Supplier Name:</span>
              <span id="modal-supplier-name" class="modal-value"></span>
            </div>
            <div class="modal-info-row">
            <span class="modal-label">Invoice No:</span>
            <span id="modal-invoice_no" class="modal-value"></span>
          </div>
          <div class="modal-info-row">
            <span class="modal-label">Purchase Date:</span>
            <span id="modal-purchase_date" class="modal-value"></span>
          </div>
          <div class="modal-info-row">
            <span class="modal-label">Total Amount:</span>
            <span id="modal-total_amount" class="modal-value"></span>
          </div>
        </div>

        <hr>
        <p><strong>Batches</strong></p>
        <div id="modal-availability-grid"></div>
      </div>
    </div>
  </div>
</div>
   
   

<!-- Modal -->
<!-- Purchase Modal -->
<div class="modal fade" id="addpurchaseModal" tabindex="-1" aria-labelledby="addpurchaseModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <form id="addpurchaseForm">
        <div class="modal-header">
          <h5 class="modal-title" id="addpurchaseModalLabel">Add Purchase</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body row g-3">
            <input type="hidden" id="id" name="id">

          <div class="col-md-6 mb-3">
         <label class="form-label">Search Supplier</label>
              <div class="input-group">
                <span class="input-group-text">
                  <i class="bi bi-search"></i> {{-- Bootstrap Icons --}}
                </span>
                <input type="text" class="form-control" name="search" id="search" placeholder="Type supplier name">
              </div>

          
            <select class="form-control" name="supplier_id" id="supplier_id" required style="width: 100%;">
              <option value="">-- Select Supplier --</option>
            
          </select>
        </div>

          <div class="col-md-6">
            <label class="form-label">Invoice No</label>
            <input type="text" class="form-control" name="invoice_no" id="invoice_no" required>
          </div>

          <div class="col-md-6">
            <label class="form-label">Purchase Date</label>
            <input type="date" class="form-control" name="purchase_date" id="purchase_date" required>
          </div>

          <div class="col-md-6">
            <label class="form-label">Total Amount</label>
            <input type="text" class="form-control" name="total_amount" id="total_amount" required>
          </div>

          <!-- Batches -->
          <div id="batchContainer" class="col-12"></div>

          <div class="col-12 mb-2">
            <button type="button" class="btn btn-secondary" onclick="addBatchSlot()">+ Add Batch</button>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Save</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>


@endsection
@push('scripts')

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script src="{{ asset('js/purchasescript.js') }}"></script>
//search
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
@push('scripts')
<script>
let batchCount = 1;

function addBatchSlot(batch = {}) {
  const container = document.getElementById('batchContainer');
  const id = batchCount++;

  const batchHTML = `
    <div class="row align-items-end border rounded p-2 mb-2" id="batch-${id}">
      
    
    <div class="col-md-2">


        <label class="form-label">Product</label>
        <select class="form-control" name="batches[${id}][product_id]" required>
          <option value="">-- Select Product --</option>
          @foreach ($productsData as $product)
           <option value="{{ $product['id'] }}" ${batch.product_id == '{{ $product['id'] }}' ? 'selected' : ''}> {{ $product['name'] }}</option>
          @endforeach
        </select>
      </div>

      <div class="col-md-2">
        <label class="form-label">Batch No</label>
        <input type="text" class="form-control" name="batches[${id}][batch_no]" value="${batch.batch_no || ''}" required>
      </div>

      <div class="col-md-2">
        <label class="form-label">Expiry Date</label>
        <input type="date" class="form-control" name="batches[${id}][expiry_date]" value="${batch.expiry_date || ''}" required>
      </div>
      

      <div class="col-md-1">
        <label class="form-label">Qty</label>
        <input type="number" class="form-control" name="batches[${id}][quantity]" value="${batch.quantity || 1}" required>
      </div>

      <div class="col-md-2">
        <label class="form-label">MRP</label>
        <input type="text" class="form-control" name="batches[${id}][mrp]" value="${batch.mrp || ''}" required>
      </div>

      <div class="col-md-2">
        <label class="form-label">Price</label>
        <input type="text" class="form-control" name="batches[${id}][purchase_price]" value="${batch.purchase_price || ''}" required>
      </div>
       <div class="col-md-2">
        <label class="form-label">Gst per</label>
        <input type="text" class="form-control" name="batches[${id}][gst_percent]" value="${batch.gst_percent || ''}" required>
      </div>

      <div class="col-md-1 text-end">
        <button type="button" class="btn btn-danger btn-sm mt-4" onclick="removeBatchSlot(${id})">Remove</button>
      </div>
    </div>
  `;

  container.insertAdjacentHTML('beforeend', batchHTML);
}

function removeBatchSlot(id) {
  const element = document.getElementById(`batch-${id}`);
  if (element) element.remove();
}


</script>

<script>

</script>




@endpush






